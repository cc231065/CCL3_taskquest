package com.example.cc231065_tasklistapp.ui.theme

import androidx.compose.ui.graphics.Color

val Blue200 = Color(0xFF03A9F4)
val Blue700 = Color(0xFF0288D1)
val White = Color(0xFFFFFFFF)
val Black = Color(0xFF000000)
